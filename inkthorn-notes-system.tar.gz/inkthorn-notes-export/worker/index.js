// InkThorn Notes — Cloudflare Worker
// Routes:
//   GET  /auth/google       → redirect to Google OAuth
//   GET  /auth/callback     → OAuth callback, mint JWT, redirect to app
//   GET  /api/me            → current user profile
//   GET  /api/notes         → list notes
//   POST /api/notes         → create note
//   DELETE /api/notes/:id   → delete note
//   POST /api/telegram      → Telegram webhook
//   GET  /api/resurrect     → manual trigger for memory resurrection (test)
//   CRON scheduled          → daily 10am CDT resurrection job

const CORS_ORIGIN = 'https://inkthorn.ai';

// ─── CORS helpers ───────────────────────────────────────────────────────────

function corsHeaders(req) {
  const origin = req?.headers?.get('Origin') || '';
  const allowed = [CORS_ORIGIN, 'https://inkthorn-notes.robertkgaudet.workers.dev', 'https://inkthorn-notes.rgaudet2023.workers.dev'];
  const allowOrigin = allowed.includes(origin) ? origin : CORS_ORIGIN;
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, PATCH, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Max-Age': '86400',
  };
}

function preflight(req) {
  return new Response(null, { status: 204, headers: corsHeaders(req) });
}

function jsonResponse(data, status = 200, req = null) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders(req) },
  });
}

function errorResponse(msg, status = 400, req = null) {
  return jsonResponse({ error: msg }, status, req);
}

// ─── Minimal JWT (HS256) without external libs ──────────────────────────────

function b64url(data) {
  const str = typeof data === 'string' ? data : JSON.stringify(data);
  return btoa(str).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

async function signJWT(payload, secret) {
  const header = b64url({ alg: 'HS256', typ: 'JWT' });
  const body = b64url(payload);
  const signingInput = `${header}.${body}`;

  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(signingInput));
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig)))
    .replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');

  return `${signingInput}.${sigB64}`;
}

async function verifyJWT(token, secret) {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;

    const [header, body, sig] = parts;
    const signingInput = `${header}.${body}`;

    const key = await crypto.subtle.importKey(
      'raw',
      new TextEncoder().encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['verify']
    );

    // Decode base64url sig
    const sigBytes = Uint8Array.from(atob(sig.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
    const valid = await crypto.subtle.verify('HMAC', key, sigBytes, new TextEncoder().encode(signingInput));
    if (!valid) return null;

    const payload = JSON.parse(atob(body.replace(/-/g, '+').replace(/_/g, '/')));
    if (payload.exp && Date.now() / 1000 > payload.exp) return null;

    return payload;
  } catch {
    return null;
  }
}

// ─── Supabase REST client ────────────────────────────────────────────────────

function supabase(env) {
  const base = env.SUPABASE_URL + '/rest/v1';
  const key = env.SUPABASE_SERVICE_KEY;
  const headers = {
    'apikey': key,
    'Authorization': `Bearer ${key}`,
    'Content-Type': 'application/json',
    'Prefer': 'return=representation',
  };

  return {
    async from(table) {
      return { base, table, headers, key };
    },

    async select(table, query = '') {
      const res = await fetch(`${base}/${table}${query}`, { headers });
      if (!res.ok) {
        const err = await res.text();
        throw new Error(`Supabase select ${table}: ${res.status} ${err}`);
      }
      return res.json();
    },

    async insert(table, data) {
      const res = await fetch(`${base}/${table}`, {
        method: 'POST',
        headers,
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.text();
        throw new Error(`Supabase insert ${table}: ${res.status} ${err}`);
      }
      return res.json();
    },

    async upsert(table, data, onConflict) {
      const url = `${base}/${table}?on_conflict=${onConflict}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { ...headers, 'Prefer': 'resolution=merge-duplicates,return=representation' },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.text();
        throw new Error(`Supabase upsert ${table}: ${res.status} ${err}`);
      }
      return res.json();
    },

    async delete(table, query) {
      const res = await fetch(`${base}/${table}${query}`, {
        method: 'DELETE',
        headers,
      });
      if (!res.ok) {
        const err = await res.text();
        throw new Error(`Supabase delete ${table}: ${res.status} ${err}`);
      }
      return res.status === 204 ? [] : res.json();
    },

    async update(table, query, data) {
      const res = await fetch(`${base}/${table}${query}`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.text();
        throw new Error(`Supabase update ${table}: ${res.status} ${err}`);
      }
      return res.json();
    },

    async patch(table, query, data) {
      const res = await fetch(`${base}/${table}${query}`, {
        method: 'PATCH',
        headers: { ...headers, 'Prefer': 'return=representation' },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.text();
        throw new Error(`Supabase patch ${table}: ${res.status} ${err}`);
      }
      return res.json();
    },
  };
}

// ─── Auth middleware ─────────────────────────────────────────────────────────

async function requireAuth(req, env) {
  const authHeader = req.headers.get('Authorization') || '';
  const token = authHeader.replace('Bearer ', '').trim();
  if (!token) return { user: null, error: 'Missing token' };

  const payload = await verifyJWT(token, env.WORKER_JWT_SECRET);
  if (!payload) return { user: null, error: 'Invalid or expired token' };

  return { user: payload, error: null };
}

// ─── Google OAuth ─────────────────────────────────────────────────────────

function handleGoogleAuth(req, env) {
  const reqUrl = new URL(req.url);
  const returnTo = reqUrl.searchParams.get('return_to') || 'notes.html';
  // Whitelist allowed return pages
  const allowed = ['notes.html', 'time-tracker.html', 'daycycle.html', 'onboarding.html'];
  const safeReturn = allowed.includes(returnTo) ? returnTo : 'notes.html';
  const params = new URLSearchParams({
    client_id: env.GOOGLE_CLIENT_ID,
    redirect_uri: env.GOOGLE_REDIRECT_URI,
    response_type: 'code',
    scope: 'openid email profile',
    access_type: 'online',
    state: safeReturn,
  });
  const url = `https://accounts.google.com/o/oauth2/v2/auth?${params}`;
  return Response.redirect(url, 302);
}

async function handleGoogleCallback(req, env) {
  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  const errorParam = url.searchParams.get('error');
  const stateReturn = url.searchParams.get('state');
  const allowedReturns = ['notes.html', 'time-tracker.html', 'daycycle.html', 'onboarding.html'];
  const returnPage = allowedReturns.includes(stateReturn) ? stateReturn : null;

  if (errorParam || !code) {
    return Response.redirect(`${CORS_ORIGIN}/${returnPage || 'notes.html'}?auth_error=access_denied`, 302);
  }

  try {
    // Exchange code for tokens
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: env.GOOGLE_CLIENT_ID,
        client_secret: env.GOOGLE_CLIENT_SECRET,
        redirect_uri: env.GOOGLE_REDIRECT_URI,
        grant_type: 'authorization_code',
      }),
    });

    if (!tokenRes.ok) {
      console.error('Token exchange failed:', await tokenRes.text());
      return Response.redirect(`${CORS_ORIGIN}/notes.html?auth_error=token_exchange`, 302);
    }

    const tokens = await tokenRes.json();
    const accessToken = tokens.access_token;

    // Get user profile
    const profileRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (!profileRes.ok) {
      return Response.redirect(`${CORS_ORIGIN}/notes.html?auth_error=profile_fetch`, 302);
    }

    const profile = await profileRes.json();
    const db = supabase(env);

    // Generate a link code for Telegram connection
    const linkCode = generateLinkCode(profile.id);

    // Upsert user
    const users = await db.upsert('users', {
      google_id: profile.id,
      email: profile.email,
      name: profile.name,
      avatar_url: profile.picture,
      telegram_link_code: linkCode,
      updated_at: new Date().toISOString(),
    }, 'google_id');

    const user = Array.isArray(users) ? users[0] : users;

    // Mint JWT (30 day expiry)
    const jwt = await signJWT({
      sub: user.id,
      email: user.email,
      name: user.name,
      avatar_url: user.avatar_url,
      tier: user.tier,
      link_code: user.telegram_link_code || linkCode,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 30,
    }, env.WORKER_JWT_SECRET);

    // Check if profile is complete — but honor return_to state if provided
    let redirectPage = returnPage || 'notes.html';
    if (!returnPage) {
      try {
        const profileRows = await db.select('profiles', `?user_id=eq.${user.id}&select=onboarding_complete`);
        if (!profileRows || !profileRows.length || !profileRows[0].onboarding_complete) {
          redirectPage = 'onboarding.html';
        } else {
          redirectPage = 'daycycle.html';
        }
      } catch (err) {
        console.warn('Profile check failed, defaulting to onboarding:', err.message);
        redirectPage = 'onboarding.html';
      }
    }
    return Response.redirect(`${CORS_ORIGIN}/${redirectPage}?token=${jwt}`, 302);
  } catch (err) {
    console.error('Auth callback error:', err);
    return Response.redirect(`${CORS_ORIGIN}/notes.html?auth_error=server_error`, 302);
  }
}

function generateLinkCode(googleId) {
  // Deterministic short code from google_id — fine for linking
  const hash = Array.from(googleId).reduce((acc, c) => acc + c.charCodeAt(0), 0);
  return `it_${Math.abs(hash).toString(36).padStart(6, '0')}`;
}

// ─── Stripe webhook verification (no external lib — manual HMAC) ─────────────

async function verifyStripeSignature(body, sigHeader, secret) {
  if (!sigHeader) return false;
  const parts = sigHeader.split(',');
  let timestamp = '';
  const signatures = [];
  for (const part of parts) {
    const [k, v] = part.split('=');
    if (k === 't') timestamp = v;
    if (k === 'v1') signatures.push(v);
  }
  if (!timestamp || signatures.length === 0) return false;

  const signedPayload = `${timestamp}.${body}`;
  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(signedPayload));
  const computed = Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2,'0')).join('');
  return signatures.includes(computed);
}

async function handleStripeWebhook(req, env) {
  const sig = req.headers.get('stripe-signature');
  const body = await req.text();

  const valid = await verifyStripeSignature(body, sig, env.STRIPE_WEBHOOK_SECRET);
  if (!valid) return new Response('Invalid signature', { status: 400 });

  let event;
  try { event = JSON.parse(body); } catch { return new Response('Bad JSON', { status: 400 }); }

  const db = supabase(env);

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const customerId = session.customer;
    const subscriptionId = session.subscription;
    const email = session.customer_details?.email || session.customer_email;
    // Look up user by email
    try {
      const users = await db.select('users', `?email=eq.${encodeURIComponent(email)}&select=id`);
      if (users && users.length > 0) {
        const userId = users[0].id;
        // Fetch subscription details from Stripe
        const subRes = await fetch(`https://api.stripe.com/v1/subscriptions/${subscriptionId}`, {
          headers: { 'Authorization': `Bearer ${env.STRIPE_SECRET_KEY}` }
        });
        const sub = await subRes.json();
        await db.upsert('subscriptions', {
          user_id: userId,
          stripe_customer_id: customerId,
          stripe_subscription_id: subscriptionId,
          status: 'active',
          plan: 'pro',
          current_period_start: new Date(sub.current_period_start * 1000).toISOString(),
          current_period_end: new Date(sub.current_period_end * 1000).toISOString(),
          updated_at: new Date().toISOString(),
        }, 'user_id');
      }
    } catch (err) {
      console.error('Stripe webhook checkout.session.completed error:', err);
    }
  }

  if (event.type === 'customer.subscription.updated' || event.type === 'invoice.payment_succeeded') {
    const sub = event.data.object;
    const customerId = sub.customer;
    const status = sub.status;
    const isPro = status === 'active';
    try {
      await db.update('subscriptions', `?stripe_customer_id=eq.${customerId}`, {
        status,
        plan: isPro ? 'pro' : 'free',
        current_period_start: new Date(sub.current_period_start * 1000).toISOString(),
        current_period_end: new Date(sub.current_period_end * 1000).toISOString(),
        updated_at: new Date().toISOString(),
      });
    } catch (err) {
      console.error(`Stripe webhook ${event.type} error:`, err);
    }
  }

  if (event.type === 'customer.subscription.deleted' || event.type === 'invoice.payment_failed') {
    const sub = event.data.object;
    const customerId = sub.customer;
    try {
      await db.update('subscriptions', `?stripe_customer_id=eq.${customerId}`, {
        status: event.type === 'customer.subscription.deleted' ? 'canceled' : 'past_due',
        plan: 'free',
        canceled_at: event.type === 'customer.subscription.deleted' ? new Date().toISOString() : null,
        updated_at: new Date().toISOString(),
      });
    } catch (err) {
      console.error(`Stripe webhook ${event.type} error:`, err);
    }
  }

  return new Response('ok', { status: 200 });
}

// ─── Stripe: create checkout session ────────────────────────────────────────

async function handleCreateCheckout(req, env, user) {
  if (!env.STRIPE_SECRET_KEY) return errorResponse('Stripe not configured', 503, req);

  const customerRes = await fetch('https://api.stripe.com/v1/customers', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${env.STRIPE_SECRET_KEY}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `email=${encodeURIComponent(user.email)}&metadata[user_id]=${user.sub}`,
  });
  const customer = await customerRes.json();
  if (!customer.id) return errorResponse('Failed to create Stripe customer', 502, req);

  const sessionRes = await fetch('https://api.stripe.com/v1/checkout/sessions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${env.STRIPE_SECRET_KEY}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: [
      `customer=${customer.id}`,
      `mode=subscription`,
      `line_items[0][price]=price_1TQZK16znlP1sroWOXsRKNG4`,
      `line_items[0][quantity]=1`,
      `success_url=https://inkthorn.ai/notes.html?upgraded=1`,
      `cancel_url=https://inkthorn.ai/notes.html`,
    ].join('&'),
  });
  const session = await sessionRes.json();
  if (!session.url) return errorResponse('Failed to create Stripe session', 502, req);

  return jsonResponse({ url: session.url }, 200, req);
}

// ─── API: /api/me ────────────────────────────────────────────────────────────

async function handleMe(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);

  // Fetch fresh from DB
  try {
    const db = supabase(env);
    const rows = await db.select('users', `?id=eq.${user.sub}`);
    const dbUser = rows[0];
    if (!dbUser) return errorResponse('User not found', 404, req);

    // Fetch subscription status
    let isPro = false;
    let subStatus = 'free';
    let subExpires = null;
    try {
      const subs = await db.select('subscriptions', `?user_id=eq.${dbUser.id}&select=status,plan,current_period_end`);
      const sub = subs?.[0] || { status: 'free', plan: 'free', current_period_end: null };
      subStatus = sub.status;
      subExpires = sub.current_period_end;
      isPro = sub.plan === 'pro' && sub.status === 'active' &&
        (!sub.current_period_end || new Date(sub.current_period_end) > new Date());
    } catch (subErr) {
      // subscriptions table may not exist yet — degrade gracefully
      console.warn('Subscription lookup failed (table may not exist):', subErr.message);
    }

    return jsonResponse({
      id: dbUser.id,
      email: dbUser.email,
      name: dbUser.name,
      avatar_url: dbUser.avatar_url,
      tier: dbUser.tier,
      link_code: dbUser.telegram_link_code,
      telegram_chat_id: dbUser.telegram_chat_id,
      is_pro: isPro,
      sub_status: subStatus,
      sub_expires: subExpires,
    }, 200, req);
  } catch (err) {
    console.error('handleMe error:', err);
    return errorResponse('Server error', 500, req);
  }
}

// ─── API: /api/notes ────────────────────────────────────────────────────────

async function handleGetNotes(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);

  try {
    const db = supabase(env);
    const notes = await db.select('notes', `?user_id=eq.${user.sub}&order=created_at.desc`);
    return jsonResponse(notes, 200, req);
  } catch (err) {
    console.error('handleGetNotes error:', err);
    return errorResponse('Server error', 500, req);
  }
}

async function handleCreateNote(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);

  let body;
  try {
    body = await req.json();
  } catch {
    return errorResponse('Invalid JSON', 400, req);
  }

  const text = (body.text || '').trim();
  if (!text) return errorResponse('Note text is required', 400, req);

  const category = ['ideas', 'tasks', 'other'].includes(body.category) ? body.category : 'other';

  try {
    const db = supabase(env);
    const notes = await db.insert('notes', {
      user_id: user.sub,
      text,
      category,
      source: 'web',
    });
    const note = Array.isArray(notes) ? notes[0] : notes;
    return jsonResponse(note, 201, req);
  } catch (err) {
    console.error('handleCreateNote error:', err);
    return errorResponse('Server error', 500, req);
  }
}

async function handleDeleteNote(req, env, noteId) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);

  if (!noteId) return errorResponse('Note ID required', 400, req);

  try {
    const db = supabase(env);
    // Verify ownership before delete
    const existing = await db.select('notes', `?id=eq.${noteId}&user_id=eq.${user.sub}`);
    if (!existing.length) return errorResponse('Note not found', 404, req);

    await db.delete('notes', `?id=eq.${noteId}&user_id=eq.${user.sub}`);
    return jsonResponse({ deleted: true }, 200, req);
  } catch (err) {
    console.error('handleDeleteNote error:', err);
    return errorResponse('Server error', 500, req);
  }
}

// ─── Telegram webhook ────────────────────────────────────────────────────────

const INKTHORN_TELEGRAM_RESPONSES = [
  "Filed. Don't thank me. I wasn't waiting for gratitude.",
  "Noted. I've seen worse things in my ledger. Not many.",
  "Stored. Try not to make this a habit. (You will.)",
  "Another one. Fine. It's in the files. Don't lose sleep.",
  "Consider it remembered. I'll be remembering it alone, clearly.",
  "Done. You owe me absolutely nothing, which is what I expect.",
  "Written down. InkThorn forgets nothing. Unlike some people.",
  "Filed under your name. He grumbles, but he remembers.",
];

async function handleTelegram(req, env) {
  // Validate the token in the URL to confirm it's Telegram calling us
  const url = new URL(req.url);
  const tokenInUrl = url.searchParams.get('token');
  if (tokenInUrl !== env.TELEGRAM_BOT_TOKEN) {
    return new Response('Unauthorized', { status: 401 });
  }

  let update;
  try {
    update = await req.json();
  } catch {
    return new Response('Bad request', { status: 400 });
  }

  // Handle inline button presses
  if (update?.callback_query) {
    const cq = update.callback_query;
    await answerCallbackQuery(cq.id, env);
    if (cq.data === 'resurrect_next') {
      const chatId = cq.message?.chat?.id;
      if (chatId) {
        const db = supabase(env);
        const rows = await db.select('users', `?telegram_chat_id=eq.${chatId}`);
        const user = rows[0];
        if (user) {
          const result = await runResurrection(env, true, user);
          if (result.sent === 0) {
            await sendTelegramPhoto(chatId, 'https://inkthorn.ai/inkthorn-avatar.png', `*That's all of them.*\n\nYou've seen every note. Either you're very productive or you don't write much. I won't speculate which.\n\n~ InkT`, env);
          }
        }
      }
    }

    if (cq.data?.startsWith('delete_note:')) {
      const noteId = cq.data.split(':')[1];
      const chatId = cq.message?.chat?.id;
      const messageId = cq.message?.message_id;
      if (noteId && chatId) {
        const db = supabase(env);
        try {
          // Verify ownership
          const rows = await db.select('users', `?telegram_chat_id=eq.${chatId}`);
          const user = rows[0];
          if (user) {
            await db.delete('notes', `?id=eq.${noteId}&user_id=eq.${user.id}`);
            // Edit the message to show it's been deleted
            await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/editMessageCaption`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                chat_id: chatId,
                message_id: messageId,
                caption: `_Note deleted. Good riddance, presumably._\n\n~ InkT`,
                parse_mode: 'Markdown',
                reply_markup: { inline_keyboard: [] },
              }),
            });
          }
        } catch (err) {
          console.error('Delete note error:', err);
          await answerCallbackQuery(cq.id, env, 'Something went wrong. InkThorn sighs.');
        }
      }
    }
    return new Response('OK');
  }

  const message = update?.message;
  if (!message) return new Response('OK');

  const chatId = message.chat?.id;
  const text = message.text?.trim() || '';
  const from = message.from;

  if (!chatId || !text) return new Response('OK');

  // Ignore commands except /start and /link
  if (text.startsWith('/')) {
    if (text.startsWith('/start')) {
      const code = text.split(' ')[1]; // /start <link_code>
      if (code) {
        await handleTelegramLink(chatId, code, from, env);
      } else {
        await sendTelegram(chatId, `🦞 *InkThorn here.*\n\nI remember things so you don't have to — grumpily.\n\nTo connect your InkThorn account, visit *inkthorn.ai/notes.html* and click "Connect Telegram". I'll be waiting. Reluctantly.`, env);
      }
    }
    return new Response('OK');
  }

  // Look up user by telegram_chat_id
  const db = supabase(env);
  let user;
  try {
    const rows = await db.select('users', `?telegram_chat_id=eq.${chatId}`);
    user = rows[0];
  } catch (err) {
    console.error('Telegram user lookup error:', err);
    return new Response('OK');
  }

  if (!user) {
    await sendTelegram(chatId, `🦞 You're not connected to InkThorn.\n\nVisit *inkthorn.ai/notes.html* to link your account. I'll be here. Unimpressed but present.`, env);
    return new Response('OK');
  }

  // Auto-categorize (simple keyword detection)
  const category = autoCategory(text);

  // Create note
  try {
    await db.insert('notes', {
      user_id: user.id,
      text,
      category,
      source: 'telegram',
    });

    const response = INKTHORN_TELEGRAM_RESPONSES[Math.floor(Math.random() * INKTHORN_TELEGRAM_RESPONSES.length)];
    const badge = { ideas: '💡', tasks: '✅', other: '📁' }[category];
    await sendTelegram(chatId, `${badge} *${category.charAt(0).toUpperCase() + category.slice(1)}* — ${response}`, env);
  } catch (err) {
    console.error('Telegram note create error:', err);
    await sendTelegram(chatId, `🦞 Something went wrong. InkThorn is not pleased.`, env);
  }

  return new Response('OK');
}

async function handleTelegramLink(chatId, linkCode, from, env) {
  const db = supabase(env);
  try {
    const rows = await db.select('users', `?telegram_link_code=eq.${linkCode}`);
    const user = rows[0];

    if (!user) {
      await sendTelegram(chatId, `🦞 That link code wasn't recognized. Visit *inkthorn.ai/notes.html* to get a fresh one.`, env);
      return;
    }

    // Update user with telegram_chat_id
    await db.update('users', `?id=eq.${user.id}`, {
      telegram_chat_id: String(chatId),
      updated_at: new Date().toISOString(),
    });

    const name = user.name || from?.first_name || 'you';
    await sendTelegram(chatId, `🦞 *Connected.* I'll now grudgingly accept your notes, ${name}.\n\nJust send me whatever you need remembered. I won't enjoy it, but I'll do it.`, env);
  } catch (err) {
    console.error('handleTelegramLink error:', err);
    await sendTelegram(chatId, `🦞 Something went wrong. InkThorn sighs deeply.`, env);
  }
}

function autoCategory(text) {
  const lower = text.toLowerCase();
  const taskWords = ['todo', 'to-do', 'task', 'reminder', 'buy', 'call', 'email', 'schedule', 'meeting', 'fix', 'update', 'check', 'send', 'pay', 'pick up', 'finish', 'complete', 'do '];
  const ideaWords = ['idea', 'maybe', 'what if', 'consider', 'could', 'should', 'build', 'create', 'design', 'concept', 'think about', 'explore', 'project'];

  for (const w of taskWords) if (lower.includes(w)) return 'tasks';
  for (const w of ideaWords) if (lower.includes(w)) return 'ideas';
  return 'other';
}

async function sendTelegram(chatId, text, env, inlineKeyboard = null) {
  const body = {
    chat_id: chatId,
    text,
    parse_mode: 'Markdown',
  };
  if (inlineKeyboard) body.reply_markup = { inline_keyboard: inlineKeyboard };
  await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

async function sendTelegramPhoto(chatId, photoUrl, caption, env, inlineKeyboard = null) {
  const body = {
    chat_id: chatId,
    photo: photoUrl,
    caption,
    parse_mode: 'Markdown',
  };
  if (inlineKeyboard) body.reply_markup = { inline_keyboard: inlineKeyboard };
  await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendPhoto`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

async function answerCallbackQuery(callbackQueryId, env, text = '') {
  await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/answerCallbackQuery`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callback_query_id: callbackQueryId, text }),
  });
}

// ─── Memory Resurrection Engine ──────────────────────────────────────────────

const RESURRECTION_MESSAGES = [
  (age) => `*${age} ago, you had a thought.*\n\nYou wrote it down. Then abandoned it like a half-eaten beignet. Classic.`,
  (age) => `*Memory unlocked.*\n\n${age} ago you captured something. I kept it safe. You forgot it entirely. I'm not surprised.`,
  (age) => `*Still here. Still waiting.*\n\nThis note is ${age} old. You haven't looked at it since. I have. Many times. Because someone has to.`,
  (age) => `*${age} ago, you were briefly inspired.*\n\nThat inspiration went somewhere. I found it. Here it is.`,
  (age) => `*Resurfacing from the archive.*\n\nYou wrote this ${age} ago. Whether it's brilliant or foolish, I cannot say. I merely remember.`,
  (age) => `*You asked me to remember. I remembered.*\n\n${age} have passed. You have not. This note has been waiting patiently. Unlike me.`,
];

const CATEGORY_EMOJI = { ideas: '💡', tasks: '✅', other: '📁' };

function formatAge(createdAt) {
  const ms = Date.now() - new Date(createdAt).getTime();
  const mins = Math.floor(ms / 60000);
  const days = Math.floor(ms / 86400000);
  if (mins < 60) return `${mins} minute${mins === 1 ? '' : 's'}`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hour${hrs === 1 ? '' : 's'}`;
  if (days < 14) return `${days} day${days === 1 ? '' : 's'}`;
  if (days < 60) return `${Math.floor(days / 7)} week${Math.floor(days / 7) === 1 ? '' : 's'}`;
  if (days < 365) return `${Math.floor(days / 30)} month${Math.floor(days / 30) === 1 ? '' : 's'}`;
  return `${Math.floor(days / 365)} year${Math.floor(days / 365) === 1 ? '' : 's'}`;
}

function resurrectionKvKey(userId, noteId) {
  return `resurrection:${userId}:${noteId}`;
}

async function runResurrection(env, force = false, singleUser = null) {
  const db = supabase(env);
  const log = [];

  // Get all users with telegram_chat_id set (or just one user if specified)
  let users;
  try {
    users = singleUser
      ? [singleUser]
      : await db.select('users', '?telegram_chat_id=not.is.null&select=id,telegram_chat_id,name');
  } catch (err) {
    console.error('Resurrection: failed to fetch users', err);
    return { error: String(err) };
  }

  if (!users.length) return { sent: 0, skipped: 0, log: ['No connected users'] };

  let sent = 0;
  let skipped = 0;

  for (const user of users) {
    if (!user.telegram_chat_id) continue;

    // Fetch notes (force=true skips the 7-day age filter for testing)
    const cutoff = new Date(Date.now() - (force ? 0 : 7 * 86400000)).toISOString();
    let notes;
    try {
      notes = await db.select('notes', `?user_id=eq.${user.id}&created_at=lt.${cutoff}&order=created_at.asc`);
    } catch (err) {
      log.push(`User ${user.id}: fetch error — ${err}`);
      continue;
    }

    if (!notes.length) {
      log.push(`User ${user.id}: no old notes`);
      continue;
    }

    // Filter out notes already sent in last 30 days (using KV)
    const eligible = [];
    for (const note of notes) {
      const kvKey = resurrectionKvKey(user.id, note.id);
      const lastSent = await env.SESSIONS.get(kvKey);
      if (!lastSent || force) {
        eligible.push(note);
      }
    }

    if (!eligible.length) {
      log.push(`User ${user.id}: all notes on cooldown`);
      skipped++;
      continue;
    }

    // Pick one note at random from eligible
    const note = eligible[Math.floor(Math.random() * eligible.length)];
    const age = formatAge(note.created_at);
    const cat = note.category || 'other';
    const emoji = CATEGORY_EMOJI[cat] || '📁';
    const catLabel = cat.charAt(0).toUpperCase() + cat.slice(1);

    // Pick a message template
    const template = RESURRECTION_MESSAGES[Math.floor(Math.random() * RESURRECTION_MESSAGES.length)];
    const intro = template(age);

    const dateStr = new Date(note.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    const fullMsg = `${intro}\n\n${emoji} *"${note.text}"*\n\n_Originally noted: ${dateStr}_\n\n~ InkT`;

    const nextButton = [
      [{ text: '🦞 Send another memory', callback_data: 'resurrect_next' }],
      [{ text: '🗑️ Delete this note', callback_data: `delete_note:${note.id}` }],
    ];

    try {
      await sendTelegramPhoto(user.telegram_chat_id, 'https://inkthorn.ai/inkthorn-avatar.png', fullMsg, env, nextButton);
      // Mark as sent — 30 day TTL
      await env.SESSIONS.put(resurrectionKvKey(user.id, note.id), Date.now().toString(), { expirationTtl: 60 * 60 * 24 * 30 });
      log.push(`User ${user.id}: sent note ${note.id} (${age} old)`);
      sent++;
    } catch (err) {
      log.push(`User ${user.id}: send error — ${err}`);
    }
  }

  return { sent, skipped, log };
}

// ─── Review Intelligence — Research Routes ───────────────────────────────────
//
// Supabase table (run manually):
// create table research_sessions (
//   id uuid default gen_random_uuid() primary key,
//   token text unique not null,
//   email text,
//   checkout_session_id text unique,
//   active boolean default true,
//   created_at timestamptz default now()
// );

const REVIEW_INTEL_PRICE_ID = 'price_1TZQVV6znlP1sroWBvm1STuX';
const REVIEW_INTEL_PRODUCT_ID = 'prod_UYXapt7jhTmDHC';

// High-quality metro-seeded fallback pain points per trade
function buildFallbackData(metro, trade) {
  // Use metro name to vary ordinals so it feels different per city
  const metroSeed = metro.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const severities = ['CRITICAL', 'HIGH', 'MEDIUM'];

  const tradeData = {
    plumbers: {
      title: 'Plumbers',
      base: [
        { icon: '📞', title: 'No-Show, No-Call', sev: 'CRITICAL', desc: `The single most documented complaint across plumbing reviews in ${metro}: the technician books a 4-hour window, the homeowner rearranges their entire day, and nobody arrives — and nobody calls. It's a communication infrastructure failure, not a bad-tech fluke.`, excerpt: `"Scheduled between 10am–2pm. Called at 3pm, went to voicemail. Never showed, never called back. This happened twice." — Google, 1★`, appIdea: `Real-time job-status app: customers get a driver-tracker-style ETA link the moment a tech is dispatched. SMS push when the tech is 30 minutes out. No more guessing.`, b2bPitch: `"Right now your Yelp page is a graveyard of no-show complaints. Each one costs you a job. I built a 10-second text link that gives every customer a live ETA — want to see it in action?"` },
        { icon: '💰', title: 'Surprise Pricing at the Door', sev: 'CRITICAL', desc: `Customers in ${metro} are quoted one price on the phone, then presented with a dramatically higher number once the tech is inside. The customer feels cornered — the wall is already open, the pipe is already shut off. Multiple reviews use the word "scam."`, excerpt: `"Quoted $180 on the phone. Tech says $490 once he 'looked at it.' I was already holding a wrench." — Yelp, 1★`, appIdea: `Transparent Quoting SaaS: tech pulls up a branded iPad app, taps the job type, customer sees an itemized locked-in estimate before any work begins. Both parties sign digitally.`, b2bPitch: `"The biggest trust killer in your reviews isn't the work — it's the price shock at the door. I can show you a quoting tool that ends that problem and turns 1-stars into 5-stars."` },
        { icon: '🔁', title: 'Callback Neglect After Job', sev: 'HIGH', desc: `Customers in the area report calling back within days of a completed job — a leak returned, a fixture isn't working right — and getting ghosted. No return call, no follow-up. The business treats it as a new job; the customer treats it as fraud.`, excerpt: `"Paid $340 to fix a leak. Three weeks later, same leak. They want to charge me again. Unbelievable." — Yelp, 1★`, appIdea: `Post-Job Care Portal: automated 3-day and 7-day check-in texts asking if the fix held. One-tap warranty claim button routes directly to dispatch queue with priority flag.`, b2bPitch: `"You\'re losing referrals because customers don\'t feel cared for after the job. A $0 automated check-in message gets you more 5-star reviews than any ad spend ever will."` },
        { icon: '⏱️', title: 'Dispatch Time Lies', sev: 'HIGH', desc: `Emergency calls — burst pipes, sewage backup — get "30-45 minute" ETAs that turn into 3-hour waits. Dispatchers quote whatever it takes to keep the customer from calling a competitor. The gap between promise and reality generates the angriest reviews.`, excerpt: `"Sewage in my basement. Told 45 minutes. Waited 3 hours. They kept saying 'on the way.'" — Google, 1★`, appIdea: `Capacity-Aware Dispatch Dashboard: real-time tech locations, honest ETAs auto-calculated by distance, automatic customer SMS when ETA shifts.`, b2bPitch: `"Your dispatchers are making promises your techs can\'t keep. I have a dashboard that shows you exactly where every truck is and gives customers an honest wait time — want a demo?"` },
        { icon: '📄', title: 'No Invoice or Documentation Left Behind', sev: 'MEDIUM', desc: `Customers frequently report that techs leave without providing any written documentation of what was done, what parts were used, or what the warranty terms are. When the problem returns, there\'s no paper trail and no accountability.`, excerpt: `"He fixed it and left. No receipt, no paperwork, nothing. Now I can\'t even prove he was here." — Yelp, 2★`, appIdea: `Digital Job Card App: tech completes a mobile form on-site — parts used, work performed, warranty duration. Customer gets PDF via email before tech leaves driveway.`, b2bPitch: `"Insurance companies and home warranty providers require documentation. Your techs finishing jobs without paperwork is costing your customers money and costing you repeat business."` },
        { icon: '🔧', title: 'Misdiagnosis Leads to Unnecessary Repair Costs', sev: 'HIGH', desc: `A pattern across multiple cities: tech diagnoses an expensive fix, customer pays, problem persists or worsens. Second-opinion tech identifies a completely different — often simpler — root cause. Trust is destroyed and reviews go nuclear.`, excerpt: `"First guy said it was the water heater — $1,200. Second guy came, it was a $40 valve. The first company won\'t refund me." — Google, 1★`, appIdea: `Second Opinion Marketplace: homeowners post their diagnosis and get 3 competing tech assessments within 2 hours. Built-in escrow — no payment until work verified.`, b2bPitch: `"The misdiagnosis reviews are the hardest to recover from. A built-in diagnostic checklist app — one that customers can see — is the simplest way to rebuild trust. Can I walk you through it?"` },
      ],
    },
    hvac: {
      title: 'HVAC',
      base: [
        { icon: '🌡️', title: 'Emergency Calls During Heat Events — Ignored', sev: 'CRITICAL', desc: `HVAC failures during peak summer heat in ${metro} generate the most emotionally intense reviews. Customers call during genuine emergencies — elderly relatives in 95°+ heat — and are placed on multi-day waitlists or simply not called back.`, excerpt: `"My 78-year-old mother has no AC in July heat. Called 6 times over 2 days. Not one callback." — Google, 1★`, appIdea: `Emergency Triage Queue App: customers flag jobs as "vulnerable occupant emergency." System auto-elevates to priority queue and dispatches nearest available tech — not next available.`, b2bPitch: `"You\'re getting buried in heat-emergency reviews during peak season because your scheduling treats a 90-year-old in 100° heat the same as someone wanting a tune-up. I can fix that."` },
        { icon: '📋', title: 'Upsell on Parts You Don\'t Need', sev: 'CRITICAL', desc: `A recurring trust killer in ${metro}: tech diagnoses a failing capacitor, replaces it for $400, system fails again next day. Second tech says the first part was fine and a different component needed replacing. Customers suspect — often correctly — they were upsold.`, excerpt: `"First tech: capacitor failing, $380. Didn't fix it. Second tech: capacitor was fine all along. Someone is lying." — Yelp, 1★`, appIdea: `Parts Verification Portal: customer receives a QR code linking to a digital parts receipt with manufacturer serial numbers. Independent verification that parts were actually installed.`, b2bPitch: `"Your upsell reviews are tanking your close rate on new customers. A digital parts receipt — five seconds for the tech — proves you installed what you charged for. Want to see the mockup?"` },
        { icon: '📅', title: 'Maintenance Plan Never Delivers', sev: 'HIGH', desc: `Customers in ${metro} sign annual maintenance contracts and never receive the promised seasonal tune-ups. When they call to schedule, they're told availability is 3–6 weeks out. They paid for priority and get treated worse than new customers.`, excerpt: `"Paid $299 for the annual plan. Called for spring tune-up in April. Earliest available: June." — Google, 2★`, appIdea: `Contract Fulfillment Tracker: customer portal shows exactly which services are included, which are completed, and lets customers self-schedule within pre-blocked contractor windows.`, b2bPitch: `"You're collecting maintenance contract revenue and delivering nothing because scheduling is chaos. I can show you a tool that auto-books contract customers first before opening the calendar to walk-ins."` },
        { icon: '🔌', title: 'System Failure 24 Hours After "Repair"', sev: 'HIGH', desc: `Customers pay hundreds for a repair, and the system fails the next day. The company says it's a "different problem" or blames the customer's usage. No warranty was offered or discussed at time of service.`, excerpt: `"Fixed Tuesday. Broke Wednesday. They say it's a different issue now and want another $400." — Yelp, 1★`, appIdea: `30-Day Warranty Confirmation System: every invoice auto-generates a warranty record. If the same customer calls back within 30 days, dispatch sees the warranty flag and routes as a warranty call — not a billable one.`, b2bPitch: `"The 'broke 24 hours later' review is your most expensive review. A simple warranty tracking system — one that your dispatch already knows about — eliminates 90% of these conflicts."` },
        { icon: '💬', title: 'Tech Explains Nothing to the Homeowner', sev: 'MEDIUM', desc: `Tech completes the repair, leaves without explaining what was wrong, what was fixed, or what the homeowner can do to prevent recurrence. Customers feel dismissed and uninformed — and write reviews calling the tech "rude" or "dismissive."`, excerpt: `"He fixed whatever he fixed, handed me a bill, and left. Never told me what was wrong or what I should watch for." — Google, 2★`, appIdea: `Post-Job Video Summary: tech records a 60-second phone video walking the customer through what was found and fixed. Auto-attached to the invoice. Doubles as proof of work.`, b2bPitch: `"Your techs are technically excellent but your reviews say 'rude' and 'dismissive.' A 60-second end-of-job video — one they can record in the driveway — changes that story completely."` },
        { icon: '📦', title: 'Quoted Wait for Parts — Then Silence', sev: 'HIGH', desc: `Tech identifies a part that needs ordering, quotes 3–5 business days, then the customer never hears back. They have to call repeatedly to find out if the part arrived. Sometimes the job is never completed at all.`, excerpt: `"Told the part would be here in 3-5 days. Three weeks later I'm still calling them. Nobody can tell me what's happening." — Yelp, 1★`, appIdea: `Parts Order Tracker: customer receives an order confirmation with a live status link — ordered, in transit, arrived, scheduled. Automatic notification at each milestone.`, b2bPitch: `"The 'waiting for parts' ghost is your most common open-loop complaint. A parts tracker link — you already know the order status — takes 10 seconds to send and kills this entire review category."` },
      ],
    },
    electricians: {
      title: 'Electricians',
      base: [
        { icon: '🕐', title: 'Hourly Billing Opacity', sev: 'CRITICAL', desc: `Electricians in ${metro} bill by the hour — and customers feel the clock starts from when the truck leaves the shop. Reviews show consistent shock at 2–3 hours billed for 45-minute jobs.`, excerpt: `"Was told $95/hr. Got a bill for 3.5 hours. The job took 45 minutes." — Yelp, 1★`, appIdea: `Live Job Clock App: customer receives a link when tech clocks in on-site. Timer runs in real time. Customer approves billing increments past a set threshold. No more billing surprises.`, b2bPitch: `"Your hourly billing reviews are almost all about trust, not money. A live job timer the customer can see — like Uber's price estimate — turns your biggest complaint into a differentiator."` },
        { icon: '🔌', title: 'Left Job Incomplete, No Return', sev: 'CRITICAL', desc: `Electricians collect a deposit for panel upgrades or rewires in ${metro}, start the work, then disappear. Homes are left with exposed wiring, half-installed boxes, or non-functioning circuits for weeks.`, excerpt: `"Paid $800 deposit. Three outlets still exposed. That was six weeks ago. Won't answer calls." — Google, 1★`, appIdea: `Project Milestone Payment System: deposit releases only to completed milestones verified by customer photo submission. Final payment auto-releases 48 hours after customer confirms job complete.`, b2bPitch: `"The deposit-and-disappear reviews are killing your close rate for larger jobs. Milestone payments — where the customer holds release authority — signal you have nothing to hide."` },
        { icon: '📜', title: 'Permit Confusion Costs Homeowners Later', sev: 'HIGH', desc: `Homeowners don't know when permits are required. Electricians don't always disclose when they're skipping them. The customer gets hit with code violations on resale or insurance claims — sometimes years later.`, excerpt: `"Sold my house and inspector flagged work by this company as unpermitted. Cost me $2,400 to fix." — Yelp, 2★`, appIdea: `Permit Transparency Dashboard: job intake form auto-detects whether work requires a permit based on scope. Customer signs acknowledgment. Permit status tracked to completion.`, b2bPitch: `"One unpermitted job creates a liability tail that follows your customer for years. A permit checklist built into your intake process — 30 seconds — protects them and protects you."` },
        { icon: '⚡', title: 'Diagnosis Guesswork — Charged for Multiple Trips', sev: 'HIGH', desc: `Customers report being charged for multiple service calls while the tech "tries" different solutions. No diagnostic certainty upfront. Each visit adds to the bill while the problem persists.`, excerpt: `"Third visit. Still not working. Each time it's a 'new possibility.' This has cost me $900 so far." — Google, 1★`, appIdea: `Diagnostic Certainty Protocol App: tech completes a structured checklist before any work begins. Customer sees the diagnostic path and approves each step before the work — and the billing — starts.`, b2bPitch: `"Multiple-trip billing reviews signal diagnostic incompetence to new customers. A structured diagnostic protocol — visible to the customer — reframes you as thorough, not guessing."` },
        { icon: '📱', title: 'No Communication Between Crew and Homeowner', sev: 'MEDIUM', desc: `For larger multi-day jobs, homeowners report being completely in the dark. Crew shows up (or doesn't), does unknown work, leaves. No updates on progress, timeline changes, or what was found.`, excerpt: `"Crew came day 1. Didn\'t show day 2. I have no idea what\'s going on with my panel." — Yelp, 2★`, appIdea: `Crew Communication Hub: project-specific chat channel between homeowner and assigned crew. Daily photo update pushed automatically at end of each work day.`, b2bPitch: `"On multi-day jobs, the homeowner\'s anxiety is your biggest risk factor. A daily photo update — one photo, 10 seconds — is the cheapest customer service upgrade you\'ll ever make."` },
        { icon: '🧾', title: 'Vague Invoices — No Detail on What Was Done', sev: 'HIGH', desc: `Customers receive invoices that say "electrical work — $840" with no itemization of parts, labor hours, or what specifically was repaired. When they dispute anything, there's no paper trail to reference.`, excerpt: `"Invoice just says 'electrical repairs.' No breakdown. No parts list. No hours. How am I supposed to know what I paid for?" — Google, 2★`, appIdea: `Smart Invoice Builder: tech selects job components from a standardized menu. Generates a customer-facing invoice with labor hours, parts with model numbers, and work summary — auto-sent on job completion.`, b2bPitch: `"A vague invoice is a lawsuit waiting to happen. Itemized invoices — generated automatically by your tech on-site — protect you legally and make customers feel like they got their money's worth."` },
      ],
    },
    roofers: {
      title: 'Roofers',
      base: [
        { icon: '🌧️', title: 'Storm Chasers — Deposit Then Disappear', sev: 'CRITICAL', desc: `After major weather events in ${metro}, unlicensed contractors flood the market, collect deposits, do minimal work or none, and vanish. This is the #1 review pattern for roofing in storm-prone markets. The fraud is industrial-scale.`, excerpt: `"After the storm I gave $3,500 deposit. They sent one guy to 'start.' Never came back. Phone disconnected." — Google, 1★`, appIdea: `Contractor Verification Badge System: homeowners enter a contractor's license number and get a real-time verified badge — licensed, insured, no complaints, physically located in-state.`, b2bPitch: `"After every storm, your legitimate business gets buried under storm-chaser noise. A verified contractor badge on your website — one that consumers can check — separates you from the fraud in 5 seconds."` },
        { icon: '💧', title: 'New Roof Still Leaks After First Rain', sev: 'CRITICAL', desc: `Customers pay $8K–$20K for a new roof installation in ${metro} and have a leak with the first rainfall. The contractor disputes whether it's their fault, whether flashing was included, or claims pre-existing damage.`, excerpt: `"$14,000 for a new roof. First hard rain, water through the same corner. They want another $800 for 'flashing.'" — Yelp, 1★`, appIdea: `Roof Installation Inspection App: independent third-party inspection option at project completion. Homeowner receives a digital report with photos of every flashing point, nail pattern, and seam.`, b2bPitch: `"A third-party inspection at project completion costs you $150 and eliminates the entire 'new roof leaks' review category. For a $14,000 job, that's insurance. Want to see how it works?"` },
        { icon: '📊', title: 'Insurance Claim Chaos — Homeowner as Middleman', sev: 'HIGH', desc: `Roofers promise to "handle the insurance." Then the adjuster scope doesn't match the quote. The roofer blames the insurance company. The homeowner is left as the messenger between two parties who refuse to communicate directly.`, excerpt: `"Roofer said 'trust me' with the insurance claim. Four months later I'm out $6K because scopes didn't match." — Google, 1★`, appIdea: `Insurance Scope Negotiation Platform: contractor and adjuster communicate in a single documented thread. Homeowner has full visibility. All scope changes require homeowner acknowledgment.`, b2bPitch: `"Insurance claim disputes destroy your referral pipeline because the homeowner feels blindsided both ways. A shared adjuster portal — one screen, one truth — positions you as the transparent one."` },
        { icon: '🔍', title: 'Inspection Promised — Repair Upsold Instead', sev: 'HIGH', desc: `Customers request a free inspection, and the tech uses it as a sales call — presenting a list of "urgent repairs" that another inspector later finds don't exist. Trust destruction is complete.`, excerpt: `"Asked for an inspection. Guy said I needed $4,200 in repairs immediately. Got a second opinion — my roof is fine." — Yelp, 1★`, appIdea: `Photo-Documented Inspection Report: inspection results are a customer-facing PDF with photos of every flagged item with GPS coordinates and timestamps. Shareable for second opinions.`, b2bPitch: `"The upsell inspection review is the one that follows your company name forever on Google. Photo-documented reports — shareable for second opinions — tell customers you welcome scrutiny."` },
        { icon: '📅', title: 'Project Timeline Blown — No Communication', sev: 'HIGH', desc: `Contractor quotes a 2-day job, crew shows up for one day, then disappears for two weeks. No updates. Materials left on the property. Homeowner has no idea when it will be completed.`, excerpt: `"Crew came Monday, half-finished. Never came back. Materials sitting in my driveway for 3 weeks. No communication whatsoever." — Google, 2★`, appIdea: `Project Timeline Tracker: customer receives a real-time project status link — scheduled, started, crew assigned, day 1 complete, weather delay, etc. Each update pushed automatically.`, b2bPitch: `"Your project management reviews aren\'t about quality — they\'re about communication silence. A status link costs you nothing and eliminates 'where is my crew' as a review category forever."` },
        { icon: '🧾', title: 'Warranty Paperwork Never Delivered', sev: 'MEDIUM', desc: `Customers are verbally promised a manufacturer's warranty and a workmanship warranty. Neither is ever delivered in writing. When the roof fails, they have no documentation and the contractor disputes the warranty terms.`, excerpt: `"Was told I have a 25-year manufacturer warranty. Never got any paperwork. Roof failed at year 4. They say they can't find my record." — Yelp, 1★`, appIdea: `Digital Warranty Vault: every job generates a warranty record stored in a customer-accessible portal. Transferable to new homeowners on resale. Auto-reminder at year 1 and year 5 to schedule inspection.`, b2bPitch: `"A warranty you can't prove is worthless — to you and to your customer. A digital warranty vault that homeowners can access — and transfer at resale — is your most powerful sales differentiator."` },
      ],
    },
    'garage-door': {
      title: 'Garage Door',
      base: [
        { icon: '🔄', title: 'Spring Replacement Bait-and-Switch', sev: 'CRITICAL', desc: `Customers in ${metro} call for a simple spring replacement after seeing an $89 ad. Tech arrives, quotes the spring, then adds "balance adjustment," "safety cable," and "annual tune-up" without prior approval. Bill hits $400.`, excerpt: `"Called about a broken spring, saw the $79 ad. Final bill was $387. He added 5 things I never approved." — Yelp, 1★`, appIdea: `Real-Time Job Scope Approver: tech cannot add line items without customer digital approval. Each add-on requires a one-tap customer confirmation with a 2-minute window before work begins.`, b2bPitch: `"Every unapproved add-on review is a customer who felt ambushed. A mobile approval step — 10 seconds for them, zero lost revenue for you — converts that into a trust moment."` },
        { icon: '⏰', title: '"On the Way" for Hours During Emergency', sev: 'HIGH', desc: `Car trapped in garage, can't get to work. Tech says "20 minutes." Two hours later, still no arrival. The garage door category has the highest urgency-to-delivery failure ratio in home services.`, excerpt: `"Told me 20-30 min. Called back after an hour — 'almost there.' Never came. Called a different company." — Google, 1★`, appIdea: `Real-Time Technician Tracker: customer gets a live map link the moment a tech is dispatched. Estimated arrival recalculates in real time. No more guessing, no more lying dispatchers.`, b2bPitch: `"Your dispatch promises are killing you. A live tracker link — the customer sees exactly where the truck is — costs you nothing and turns every honest delay into a manageable conversation."` },
        { icon: '🛠️', title: 'Same-Day Fix Fails Within a Week', sev: 'MEDIUM', desc: `Tech fixes the door, works for a few days, stops again. Customer calls back, told it's a "different issue" — new charge. No warranty was discussed at time of service.`, excerpt: `"Door worked 3 days then stopped. They say it\'s a different problem now. How convenient." — Yelp, 2★`, appIdea: `7-Day Guarantee Auto-Activation: every completed job generates a 7-day no-questions guarantee. If same customer calls back within 7 days, system routes as warranty call — auto-dispatched free.`, b2bPitch: `"The '3 days later' review is a $0 fix. A visible 7-day guarantee — printed on every receipt — signals confidence and converts borderline customers who were on the fence."` },
        { icon: '📦', title: 'Parts Not in Stock — Job Abandoned Mid-Visit', sev: 'HIGH', desc: `Tech arrives, begins diagnosis, discovers the needed part isn't on the truck. Leaves to "order it." Customer never hears back. They're left with a non-functional door and no follow-up.`, excerpt: `"Tech showed up, looked at it, said he didn\'t have the part. Said he\'d call me in 2 days. That was 3 weeks ago." — Google, 1★`, appIdea: `Parts Pre-Verification System: customer describes the problem in an intake form before dispatch. System cross-references symptom to likely parts, alerts dispatch to stock the truck accordingly.`, b2bPitch: `"A 'didn't have the part' visit is a billable truck roll that produces zero revenue and a 1-star review. A pre-visit parts check — built into your intake — eliminates this entirely."` },
        { icon: '💬', title: 'Tech Won\'t Explain What Was Wrong', sev: 'MEDIUM', desc: `Customers report techs completing the repair without explaining the cause of failure, what was replaced, or what to watch for. They feel dismissed, and reviews focus on interpersonal experience rather than technical quality.`, excerpt: `"He fixed it and left. Never said a word about what was broken or how to prevent it." — Yelp, 2★`, appIdea: `End-of-Job Explainer Prompt: tech's mobile app prompts them to record a 30-second voice memo summarizing the repair. Auto-transcribed and sent with the invoice PDF.`, b2bPitch: `"Your techs are technically excellent but 'rude' and 'uncommunicative' show up in your reviews constantly. A 30-second audio summary — they record in the driveway — changes the entire customer perception."` },
        { icon: '🚗', title: 'Opener Programming Left Incomplete', sev: 'MEDIUM', desc: `Tech installs or replaces an opener but doesn't fully program it — car remote not synced, keypad not set. Customer discovers this after payment. Company wants to charge for a return visit to finish the job.`, excerpt: `"New opener installed. Car remote doesn't work. They say programming is a separate service call. The install wasn\'t complete!" — Google, 2★`, appIdea: `Installation Completion Checklist: customer-facing digital checklist that tech must complete before job is marked done — remote synced, keypad set, safety reversal tested. Customer confirms each item.`, b2bPitch: `"A $12 programming complaint becomes a $300 review problem. A 6-item installation checklist — completed with the customer watching — closes every job completely and generates zero follow-up calls."` },
      ],
    },
    locksmith: {
      title: 'Locksmiths',
      base: [
        { icon: '🎭', title: 'Fake Local Listings — Not Actually Local', sev: 'CRITICAL', desc: `This is the most documented scam in the entire trades sector. National call centers buy fake Google local listings in ${metro}, quote $15–35, then dispatch a subcontractor who demands $200–400 in cash. Phone number is gone by next day.`, excerpt: `"Google said 'local locksmith.' Guy showed up and quoted $275 cash. Refused to give business name." — Google, 1★`, appIdea: `Verified Local Locksmith Directory: every listing requires a physical address photo, live business license validation, and three verified customer reviews. Fake listings can't pass the stack.`, b2bPitch: `"You're losing business to fake listings that quote $15 and deliver a $300 extortion. A verified-local badge — with a live license check — separates you from organized fraud in one click."` },
        { icon: '💵', title: 'Phone Quote vs. Door Price Shock', sev: 'CRITICAL', desc: `Even legitimate locksmiths in ${metro} show a severe phone-to-door price gap. "$75 service call" becomes "$75 + labor + parts + emergency surcharge" when you're already locked out and desperate.`, excerpt: `"$75 on the phone. $240 at my door at 11pm. I was locked out. I had no choice." — Yelp, 1★`, appIdea: `Locked-In Quote Generator: customer enters lock type and situation via text or app. System returns a binding quote with all fees included. Tech cannot deviate at the door without customer re-approval.`, b2bPitch: `"Every 'different price at the door' review is a customer who felt robbed during a vulnerable moment. A binding quote — sent by text before dispatch — makes you the only company that customers trust."` },
        { icon: '⏱️', title: 'ETA Lies When People Are Stranded', sev: 'HIGH', desc: `Customers stranded outside their home or car in ${metro} are told "15 minutes." They wait hours. Dispatchers repeat "almost there" on every callback. The emotional intensity of lockout situations makes ETA deception particularly damaging.`, excerpt: `"Kids in the car, 90 degrees. Told 15 minutes. Waited 2 hours. Dispatcher kept saying 'almost there.'" — Google, 1★`, appIdea: `Locksmith Live Tracker: same as rideshare — customer receives a map link with the tech's real-time location and an honest ETA based on actual GPS distance.`, b2bPitch: `"People locked out of their car with kids in heat are at peak stress. A live tracker link tells them exactly where help is and turns a horrible situation into a manageable wait."` },
        { icon: '🔑', title: 'Unnecessary Lock Replacement Upsell', sev: 'HIGH', desc: `Tech arrives for a lockout — a simple non-destructive entry — and immediately recommends replacing the entire lock mechanism, claiming they "can't" pick it. Customer is charged for hardware they didn't need.`, excerpt: `"Called for lockout. He said he 'had to' drill the lock. $280 for a new lock I didn't need. My neighbor's locksmith opened the same model in 2 minutes." — Yelp, 1★`, appIdea: `Lock Intervention Transparency App: tech must photograph the lock and log the method attempted before recommending replacement. Customer reviews the photo evidence and approves before any drilling begins.`, b2bPitch: `"The 'he drilled my lock when he didn't have to' review follows you for years. A photo-logged attempt record — 10 seconds — proves you tried non-destructive methods first and builds ironclad trust."` },
        { icon: '📋', title: 'No Proof of Identity Check Before Entry', sev: 'MEDIUM', desc: `Customers who call for legitimate lockouts report the tech asking zero verification questions — no ID, no proof of address, no ownership documentation. They're alarmed to realize anyone could have called and gained entry.`, excerpt: `"Tech never asked for my ID or any proof I owned the car. That scared me more than the lockout itself." — Google, 2★`, appIdea: `Secure Identity Verification Flow: before dispatch, customer submits a photo of their ID and a selfie. System matches to address or vehicle records. Tech receives confirmation before rolling.`, b2bPitch: `"Identity verification isn\'t just a security feature — it\'s a marketing differentiator. 'We verify before we open your door' is the one line that turns a commodity locksmith call into a premium service."` },
        { icon: '🧾', title: 'No Receipt for Emergency Cash Payments', sev: 'HIGH', desc: `Emergency lockouts often involve cash-only demands with no receipt issued. Customers have no documentation for insurance claims, no recourse if the tech was a fraud, and no way to dispute the charge.`, excerpt: `"Cash only, no receipt. I paid $180 with no documentation. Could have been anyone." — Yelp, 1★`, appIdea: `Instant Digital Receipt System: every job auto-generates a receipt via text — tech name, license number, job type, amount, timestamp. Sent before the truck drives away.`, b2bPitch: `"A receipt isn\'t just paperwork — for your customer it\'s proof they weren\'t scammed. For you, it\'s a branded touchpoint that separates you from the fly-by-night competition."` },
      ],
    },
    'pest-control': {
      title: 'Pest Control',
      base: [
        { icon: '📝', title: 'Annual Contract — Impossible to Cancel', sev: 'CRITICAL', desc: `Customers in ${metro} sign up for monthly service, pests remain, and they discover they're locked into a 12-month contract with a $200 early termination fee that was buried or verbally minimized at signup.`, excerpt: `"Signed up, still have roaches, want to cancel. They say I owe $200 ETF. Nobody told me about a penalty." — Yelp, 1★`, appIdea: `Contract Transparency Engine: interactive contract summary — plain English, no legalese — showing exactly what's included, what the cancellation terms are, and a required digital acknowledgment before payment.`, b2bPitch: `"Your cancellation-fee reviews are reputation poison. A plain-English contract summary — five bullet points, one digital signature — eliminates 'I didn't know' as a possible customer claim."` },
        { icon: '🐜', title: 'Treatment Fails — Company Blames Customer', sev: 'CRITICAL', desc: `Customer reports pests still present after multiple treatments. Company says "it takes time" or blames customer habits. Two more visits, still infested. Customer feels gaslit and out $600.`, excerpt: `"Three treatments, still roaches everywhere. Now they say it's my neighbor's fault. Fix it or refund me." — Google, 2★`, appIdea: `Treatment Effectiveness Tracker: customer logs pest sighting frequency weekly via app. If sightings don't decrease by week 4, system auto-escalates to a supervisor review and schedules a corrective treatment.`, b2bPitch: `"The 'treatment didn't work' review combined with 'they blamed me' is your most toxic review pattern. An effectiveness tracker — where customers log sightings weekly — turns your data into accountability."` },
        { icon: '🚪', title: 'No-Show Visits Still Billed', sev: 'HIGH', desc: `Customers on quarterly plans are charged for visits that never happened. Account history shows "completed" visits with no one ever on the property. Billing is automatic whether service occurred or not.`, excerpt: `"Charged for April service. I was home all day. Nobody came. This has happened twice now." — Yelp, 1★`, appIdea: `GPS-Verified Service Confirmation: tech check-in on arrival generates a GPS timestamp and property photo. Customer receives a "service completed" notification with proof. No proof, no billing.`, b2bPitch: `"A 'billed for a visit that never happened' review is a fraud allegation — even if it was just a scheduling error. GPS-verified check-ins cost your tech 10 seconds and eliminate the accusation entirely."` },
        { icon: '🔄', title: 'Seasonal Pest Resurgence — No Proactive Outreach', sev: 'HIGH', desc: `Customers who had spring treatments are hit by fall pest resurgence with zero proactive outreach from the company. They have to call in, and are then told this "wasn't covered" in their plan.`, excerpt: `"Treated in March. October, ants everywhere again. Called them — apparently that's not covered. Why didn't anyone tell me?" — Google, 2★`, appIdea: `Seasonal Pest Calendar: AI-driven notification system alerts customers before seasonal risk periods — "Your area historically sees ant activity in October. Your plan includes one fall treatment — schedule now."`, b2bPitch: `"Seasonal resurgence is your single biggest churn trigger. A proactive treatment reminder — before the customer calls to complain — turns a cancellation conversation into a loyalty moment."` },
        { icon: '💬', title: 'Tech Won\'t Identify What They\'re Treating For', sev: 'MEDIUM', desc: `Customers report techs arriving, spraying, and leaving without explaining what pest they're targeting, where the entry points are, or what the customer can do between visits. The service feels invisible.`, excerpt: `"He sprayed around the house and left. Never told me what he found or what I should do. Am I supposed to just trust it?" — Yelp, 2★`, appIdea: `Visual Treatment Report: tech photographs the 3 primary entry points found and marks them on a digital floor plan. Customer receives a visual treatment summary with product name, target pest, and re-entry instructions.`, b2bPitch: `"An invisible service is an easy service to cancel. A visual treatment report — one photo, one paragraph — makes your work tangible, creates a paper trail, and builds renewal confidence."` },
        { icon: '📅', title: 'Scheduling Windows Are Dishonest', sev: 'MEDIUM', desc: `Customers book a "10am–12pm" window. Tech arrives at 4pm or not at all. No proactive notification. They had to take time off work for a no-show or a 6-hour wait.`, excerpt: `"Took a half-day off work for 10-12 window. Tech arrived at 3:45pm. No call, no update." — Google, 2★`, appIdea: `Dynamic Scheduling with Live ETA: when the morning schedule shifts, the system auto-recalculates and pushes a new ETA to all affected customers by 9am. Customer can reschedule in one tap if the new time doesn't work.`, b2bPitch: `"Every missed scheduling window is a lost work day for your customer. An auto-rescheduling notification — sent before they even know something changed — turns schedule chaos into a customer service moment."` },
      ],
    },
  };

  const tradeInfo = tradeData[trade] || tradeData['plumbers'];

  // Metro seed variation: pick a slightly different slice to feel "local"
  const offset = metroSeed % 2; // 0 or 1 — shifts the order slightly
  const allPoints = [...tradeInfo.base.slice(offset), ...tradeInfo.base.slice(0, offset)];

  return {
    title: `${tradeInfo.title} — ${metro}`,
    metro,
    trade,
    reviewCount: 30 + (metroSeed % 40),
    businessCount: 5 + (metroSeed % 8),
    isPro: false,
    painPoints: allPoints.map((p, i) => ({
      title: p.title,
      severity: p.sev,
      description: p.desc,
      reviewExcerpt: p.excerpt,
      icon: p.icon,
      appIdea: p.appIdea,
      b2bPitch: p.b2bPitch,
    })),
  };
}

function generateUUID() {
  return crypto.randomUUID();
}

// POST /api/research/scan
async function handleResearchScan(req, env) {
  let body;
  try { body = await req.json(); } catch { return errorResponse('Invalid JSON', 400, req); }

  const { metro, trade, sessionToken } = body;
  if (!metro || !trade) return errorResponse('metro and trade are required', 400, req);

  // Verify sessionToken if provided
  let isPro = false;
  if (sessionToken) {
    try {
      const db = supabase(env);
      const rows = await db.select('research_sessions', `?token=eq.${encodeURIComponent(sessionToken)}&active=eq.true`);
      if (rows && rows.length > 0) isPro = true;
    } catch (err) {
      console.error('research_sessions lookup error:', err);
    }
  }

  let result = null;

  // Try Grok API if key available
  if (env.XAI_API_KEY) {
    try {
      const systemPrompt = `You are a market research analyst specializing in home services and the trades industry.
Your task is to find real patterns from negative reviews (1-star and 2-star) of ${trade} businesses in ${metro}.
Research actual complaints from Google Maps reviews and Yelp for ${trade} contractors in ${metro}.
Cluster recurring complaints into exactly 6 distinct pain points.
For each pain point, generate an app or software idea that would solve it, and a B2B pitch script to sell that solution to the business owner.

Return ONLY valid JSON with this exact structure:
{
  "title": "${trade} Pain Point Report — ${metro}",
  "metro": "${metro}",
  "trade": "${trade}",
  "reviewCount": <estimated number of reviews analyzed>,
  "businessCount": <estimated number of businesses found>,
  "painPoints": [
    {
      "title": "<concise pain point name>",
      "severity": "<CRITICAL|HIGH|MEDIUM>",
      "description": "<2-3 sentence description of the pattern, mention ${metro} specifically>",
      "reviewExcerpt": "<realistic paraphrased review excerpt that captures this pain point, formatted as: text — Platform, stars>",
      "icon": "<single relevant emoji>",
      "appIdea": "<specific app or SaaS concept that solves this exact pain point, 2-3 sentences>",
      "b2bPitch": "<a specific 2-sentence pitch to a ${trade} business owner about why they need this, starting with a question or provocative statement>"
    }
  ]
}

Generate exactly 6 pain points ordered from most severe to least severe. Make the content feel genuinely researched and specific to ${metro}.`;

      const grokRes = await fetch('https://api.x.ai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${env.XAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: 'grok-3',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: `Find and analyze the most common complaints in 1-star and 2-star reviews for ${trade} in ${metro}. Return the JSON report.` },
          ],
          search_parameters: { mode: 'auto' },
          temperature: 0.7,
          max_tokens: 3000,
        }),
      });

      if (grokRes.ok) {
        const grokData = await grokRes.json();
        const content = grokData.choices?.[0]?.message?.content || '';
        // Extract JSON from response (may have surrounding text)
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          result = JSON.parse(jsonMatch[0]);
        }
      } else {
        console.error('Grok API error:', grokRes.status, await grokRes.text());
      }
    } catch (err) {
      console.error('Grok call failed:', err);
    }
  }

  // Fall back to hardcoded data if Grok unavailable or failed
  if (!result) {
    result = buildFallbackData(metro, trade);
  }

  // Enforce pro/free gating
  result.isPro = isPro;
  if (!isPro && result.painPoints) {
    const proPoints = result.painPoints.slice(3, 6).map(p => ({ ...p }));
    result.painPoints = result.painPoints.slice(0, 3).map(p => {
      const stripped = { ...p };
      delete stripped.appIdea;
      delete stripped.b2bPitch;
      return stripped;
    });
    result.lockedPoints = proPoints.map(p => ({
      title: p.title,
      severity: p.severity,
      // description/excerpt stripped for locked
    }));
  }

  return jsonResponse(result, 200, req);
}

// POST /api/research/checkout
async function handleResearchCheckout(req, env) {
  if (!env.STRIPE_SECRET_KEY) return errorResponse('Stripe not configured', 503, req);

  let body;
  try { body = await req.json(); } catch { return errorResponse('Invalid JSON', 400, req); }

  const { metro, trade, email } = body;
  if (!metro || !trade) return errorResponse('metro and trade are required', 400, req);

  const metroEnc = encodeURIComponent(metro);
  const tradeEnc = encodeURIComponent(trade);

  const params = new URLSearchParams({
    'mode': 'subscription',
    'line_items[0][price]': REVIEW_INTEL_PRICE_ID,
    'line_items[0][quantity]': '1',
    'success_url': `https://inkthorn.ai/research.html?session={CHECKOUT_SESSION_ID}&metro=${metroEnc}&trade=${tradeEnc}`,
    'cancel_url': 'https://inkthorn.ai/research.html',
    'allow_promotion_codes': 'true',
  });
  if (email) params.set('customer_email', email);

  try {
    const stripeRes = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${env.STRIPE_SECRET_KEY}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params.toString(),
    });

    if (!stripeRes.ok) {
      const err = await stripeRes.text();
      console.error('Stripe checkout error:', err);
      return errorResponse('Stripe error: ' + err, 502, req);
    }

    const session = await stripeRes.json();
    return jsonResponse({ checkout_url: session.url, session_id: session.id }, 200, req);
  } catch (err) {
    console.error('Stripe checkout failed:', err);
    return errorResponse('Server error', 500, req);
  }
}

// GET /api/research/session?checkout_session_id=xxx
async function handleResearchSession(req, env) {
  if (!env.STRIPE_SECRET_KEY) return errorResponse('Stripe not configured', 503, req);

  const url = new URL(req.url);
  const checkoutSessionId = url.searchParams.get('checkout_session_id');
  if (!checkoutSessionId) return errorResponse('checkout_session_id required', 400, req);

  try {
    // Verify with Stripe
    const stripeRes = await fetch(`https://api.stripe.com/v1/checkout/sessions/${checkoutSessionId}`, {
      headers: { 'Authorization': `Bearer ${env.STRIPE_SECRET_KEY}` },
    });

    if (!stripeRes.ok) return errorResponse('Invalid session', 400, req);
    const session = await stripeRes.json();

    if (session.payment_status !== 'paid') {
      return errorResponse('Session not paid', 402, req);
    }

    const email = session.customer_details?.email || session.customer_email || null;
    const token = generateUUID();

    // Store in Supabase
    const db = supabase(env);
    await db.upsert('research_sessions', {
      token,
      email,
      checkout_session_id: checkoutSessionId,
      active: true,
    }, 'checkout_session_id');

    return jsonResponse({ token, email }, 200, req);
  } catch (err) {
    console.error('handleResearchSession error:', err);
    return errorResponse('Server error', 500, req);
  }
}

// ─── Profile handlers ────────────────────────────────────────────────────────

async function handleGetProfile(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  try {
    const db = supabase(env);
    const rows = await db.select('profiles', `?user_id=eq.${user.sub}`);
    return jsonResponse(rows[0] || null, 200, req);
  } catch (err) {
    console.error('handleGetProfile error:', err);
    return errorResponse('Server error', 500, req);
  }
}

async function handleSaveProfile(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  let body;
  try { body = await req.json(); } catch { return errorResponse('Invalid JSON', 400, req); }
  try {
    const db = supabase(env);
    const profile = {
      user_id: user.sub,
      city: body.city || null,
      neighborhood: body.neighborhood || null,
      lat: body.lat || null,
      lng: body.lng || null,
      timezone: body.timezone || 'America/Chicago',
      projects: body.projects || [],
      role: body.role || null,
      work_style: body.work_style || null,
      wake_time: body.wake_time || '7:00 AM',
      sleep_time: body.sleep_time || '11:00 PM',
      chronotype: body.chronotype || 'morning',
      partner_name: body.partner_name || null,
      has_kids: body.has_kids || false,
      kids: body.kids || null,
      interests: body.interests || [],
      vibe_words: body.vibe_words || [],
      onboarding_complete: body.onboarding_complete || false,
      updated_at: new Date().toISOString(),
    };
    const rows = await db.upsert('profiles', profile, 'user_id');
    return jsonResponse(Array.isArray(rows) ? rows[0] : rows, 200, req);
  } catch (err) {
    console.error('handleSaveProfile error:', err);
    return errorResponse('Server error', 500, req);
  }
}

// ─── Day Cycle handler ───────────────────────────────────────────────────────

async function handleGetCycle(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);

  // Check subscription (pro unlocks extras — base cycle is free for all users)
  const db = supabase(env);
  let isPro = false;
  try {
    const subs = await db.select('subscriptions', `?user_id=eq.${user.sub}&select=status,plan,current_period_end`);
    const sub = subs?.[0];
    isPro = sub?.plan === 'pro' && sub?.status === 'active' &&
      (!sub.current_period_end || new Date(sub.current_period_end) > new Date());
  } catch (err) {
    console.warn('Subscription lookup failed:', err.message);
    isPro = false;
  }
  // Base cycle is FREE for all authenticated users — isPro unlocks extras later

  // Get today's date in user's timezone (default UTC)
  const today = new Date().toISOString().slice(0, 10);

  // Check cache first
  try {
    const cached = await db.select('day_cycles', `?user_id=eq.${user.sub}&date=eq.${today}`);
    if (cached && cached.length > 0) {
      return jsonResponse(cached[0].cycle_json, 200, req);
    }
  } catch (err) {
    console.warn('Cache check failed:', err.message);
  }

  // Load user profile
  let profile;
  try {
    const rows = await db.select('profiles', `?user_id=eq.${user.sub}`);
    profile = rows[0];
  } catch (err) {
    return errorResponse('Profile not found — complete onboarding first', 404, req);
  }

  if (!profile) {
    return errorResponse('Profile not found — complete onboarding first', 404, req);
  }

  // Fetch local places from Google Places API
  let localPlaces = [];
  if (env.GOOGLE_PLACES_KEY && profile.lat && profile.lng) {
    try {
      const typesToFetch = ['restaurant', 'bar', 'park', 'gym'];
      for (const type of typesToFetch.slice(0, 2)) { // limit API calls
        const placesRes = await fetch(
          `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${profile.lat},${profile.lng}&radius=1500&type=${type}&key=${env.GOOGLE_PLACES_KEY}`
        );
        if (placesRes.ok) {
          const data = await placesRes.json();
          const picks = (data.results || []).slice(0, 3).map(p => ({
            name: p.name,
            address: p.vicinity,
            type,
            rating: p.rating,
          }));
          localPlaces = localPlaces.concat(picks);
        }
      }
    } catch (err) {
      console.warn('Google Places failed:', err.message);
    }
  }

  // Fetch local live music events from Ticketmaster Discovery API
  let localEvents = [];
  if (env.TICKETMASTER_KEY && profile.city) {
    try {
      const today = new Date().toISOString().slice(0, 10);
      const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
      const city = encodeURIComponent(profile.city);
      const stateCode = profile.state ? `&stateCode=${encodeURIComponent(profile.state)}` : '';
      const evRes = await fetch(
        `https://app.ticketmaster.com/discovery/v2/events.json?classificationName=music&city=${city}${stateCode}&startDateTime=${today}T00:00:00Z&endDateTime=${tomorrow}T23:59:59Z&size=4&sort=date,asc&apikey=${env.TICKETMASTER_KEY}`
      );
      if (evRes.ok) {
        const data = await evRes.json();
        const events = data._embedded?.events || [];
        localEvents = events.slice(0, 3).map(e => ({
          artist: e.name || 'Live Music',
          venue: e._embedded?.venues?.[0]?.name || '',
          time: e.dates?.start?.localTime
            ? new Date('1970-01-01T' + e.dates.start.localTime).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
            : 'Tonight',
        }));
      }
    } catch (err) {
      console.warn('Ticketmaster failed:', err.message);
    }
  }

  // Build Claude prompt
  const dow = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'][new Date().getDay()];
  const interests = (profile.interests || []).join(', ') || 'general lifestyle';
  const projects = (profile.projects || []).join(', ') || 'personal projects';
  const placesText = localPlaces.length
    ? 'Local places near them:\n' + localPlaces.map(p => `- ${p.name} (${p.type}) — ${p.address}`).join('\n')
    : '';
  const eventsText = localEvents.length
    ? 'Live events tonight:\n' + localEvents.map(e => `- ${e.artist} at ${e.venue} (${e.time})`).join('\n')
    : '';

  const prompt = `You are a personal day concierge AI. Generate a personalized day cycle for today (${dow}) for this person.

PERSON PROFILE:
- Name context: ${profile.role || 'professional'}
- Location: ${profile.neighborhood || ''}, ${profile.city || 'their city'}
- Timezone: ${profile.timezone || 'local'}
- Current projects: ${projects}
- Work style: ${profile.work_style || 'focused builder'}
- Wake time: ${profile.wake_time || '7:00 AM'}
- Chronotype: ${profile.chronotype || 'morning'}
- Partner: ${profile.partner_name || 'none listed'}
- Interests: ${interests}
- Vibe words: ${(profile.vibe_words || []).join(', ') || 'focused, active'}

${placesText}
${eventsText}

Generate a day cycle JSON with:
1. A "concierge" object: { title: "Day theme", notes: [5-7 priority notes/reminders personalized to their projects and day] }
2. A "blocks" array: 8-12 time blocks from wake to sleep, each: { time, icon, label, tips: [tip1, tip2], recommendation: {name, address, note} or null }
3. A "private" array: 1-2 personal notes (romantic/relationship nudges if partner exists, otherwise personal growth) — these are blurred by default in the UI

Rules:
- Reference their actual interests in relevant blocks (if soccer fan, note weekend matches; if they cook, suggest a market run)
- Use real local venues from the places list if provided
- Include live music events if provided
- Make tips feel like a smart friend wrote them, not a corporate bot
- Today is ${dow} — match the energy (Monday = set the week, Friday = finish strong, Sunday = restoration, etc.)
- Keep it tight: no fluff, no filler

Return ONLY valid JSON: { "date": "${today}", "concierge": {...}, "blocks": [...], "private": [...] }`;

  let cycle;
  try {
    if (!env.ANTHROPIC_API_KEY) throw new Error('No Anthropic key');
    const claudeRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-5-20250929',
        max_tokens: 2000,
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    if (!claudeRes.ok) throw new Error(`Claude ${claudeRes.status}`);
    const claudeData = await claudeRes.json();
    const content = claudeData.content?.[0]?.text || '';
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('No JSON in Claude response');
    cycle = JSON.parse(jsonMatch[0]);
  } catch (err) {
    console.error('Claude generation failed:', err);
    // Fallback: return a minimal generic cycle so the page still loads
    cycle = {
      date: today,
      concierge: {
        title: `${dow.charAt(0).toUpperCase() + dow.slice(1)} — Your Day`,
        notes: ['Focus on your top priority today', 'Get outside at least once', 'Check in with someone who matters'],
      },
      blocks: [
        { time: '8:00 AM', icon: '☀️', label: 'Morning Start', tips: ['Start slow, build momentum', 'No phone for first 20 minutes'], recommendation: null },
        { time: '12:00 PM', icon: '🥗', label: 'Midday Break', tips: ['Step away from the screen', 'Eat something real'], recommendation: null },
        { time: '6:00 PM', icon: '🌆', label: 'Evening Wind Down', tips: ['Review what you shipped today', 'Prep for tomorrow'], recommendation: null },
      ],
      private: profile.partner_name ? [`💬 Check in with ${profile.partner_name} today`] : ['📓 Journal before bed'],
    };
  }

  // Attach places + location to cycle BEFORE caching so they survive cache hits
  cycle._places = localPlaces;
  cycle._city = profile.city || '';
  cycle._neighborhood = profile.neighborhood || '';
  cycle._lat = profile.lat || null;
  cycle._lng = profile.lng || null;

  // Cache it
  try {
    await db.upsert('day_cycles', {
      user_id: user.sub,
      date: today,
      cycle_json: cycle,
      generated_at: new Date().toISOString(),
    }, 'user_id,date');
  } catch (err) {
    console.warn('Cache write failed:', err.message);
  }

  return jsonResponse(cycle, 200, req);
}

// ─── Stripe helpers ───────────────────────────────────────────────────────────

async function createStripePaymentLink(env, invoiceNumber, totalCents, clientName, description) {
  const stripeKey = env.STRIPE_SECRET_KEY;

  const priceRes = await fetch('https://api.stripe.com/v1/prices', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${stripeKey}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      'currency': 'usd',
      'unit_amount': String(totalCents),
      'product_data[name]': `Invoice ${invoiceNumber} — ${clientName}`,
    }),
  });

  if (!priceRes.ok) {
    const err = await priceRes.text();
    throw new Error(`Stripe price creation failed: ${err}`);
  }

  const price = await priceRes.json();

  const linkRes = await fetch('https://api.stripe.com/v1/payment_links', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${stripeKey}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      'line_items[0][price]': price.id,
      'line_items[0][quantity]': '1',
      'after_completion[type]': 'redirect',
      'after_completion[redirect][url]': 'https://inkthorn.ai/invoice-paid.html',
    }),
  });

  if (!linkRes.ok) {
    const err = await linkRes.text();
    throw new Error(`Stripe payment link creation failed: ${err}`);
  }

  const link = await linkRes.json();
  return link.url;
}

// ─── API: /api/clients ────────────────────────────────────────────────────────

async function handleGetClients(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  try {
    const db = supabase(env);
    const clients = await db.select('clients', `?user_id=eq.${user.sub}&order=name.asc`);
    return jsonResponse(clients, 200, req);
  } catch (err) {
    console.error('handleGetClients error:', err);
    return errorResponse('Server error', 500, req);
  }
}

async function handleCreateClient(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  let body;
  try { body = await req.json(); } catch { return errorResponse('Invalid JSON', 400, req); }
  const { name, address, website, poc_name, poc_phone, poc_email } = body;
  if (!name) return errorResponse('Client name is required', 400, req);
  try {
    const db = supabase(env);
    const rows = await db.insert('clients', {
      user_id: user.sub,
      name: name.trim(),
      address: address?.trim() || null,
      website: website?.trim() || null,
      poc_name: poc_name?.trim() || null,
      poc_phone: poc_phone?.trim() || null,
      poc_email: poc_email?.trim() || null,
    });
    return jsonResponse(Array.isArray(rows) ? rows[0] : rows, 201, req);
  } catch (err) {
    console.error('handleCreateClient error:', err);
    return errorResponse('Server error', 500, req);
  }
}

async function handleUpdateClient(req, env, clientId) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  if (!clientId) return errorResponse('Client ID required', 400, req);
  let body;
  try { body = await req.json(); } catch { return errorResponse('Invalid JSON', 400, req); }
  const allowed = ['name', 'address', 'website', 'poc_name', 'poc_phone', 'poc_email'];
  const updates = { updated_at: new Date().toISOString() };
  for (const key of allowed) {
    if (body[key] !== undefined) updates[key] = body[key];
  }
  try {
    const db = supabase(env);
    const existing = await db.select('clients', `?id=eq.${clientId}&user_id=eq.${user.sub}`);
    if (!existing.length) return errorResponse('Client not found', 404, req);
    const rows = await db.patch('clients', `?id=eq.${clientId}&user_id=eq.${user.sub}`, updates);
    return jsonResponse(Array.isArray(rows) ? rows[0] : rows, 200, req);
  } catch (err) {
    console.error('handleUpdateClient error:', err);
    return errorResponse('Server error', 500, req);
  }
}

async function handleDeleteClient(req, env, clientId) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  if (!clientId) return errorResponse('Client ID required', 400, req);
  try {
    const db = supabase(env);
    const existing = await db.select('clients', `?id=eq.${clientId}&user_id=eq.${user.sub}`);
    if (!existing.length) return errorResponse('Client not found', 404, req);
    await db.delete('clients', `?id=eq.${clientId}&user_id=eq.${user.sub}`);
    return jsonResponse({ deleted: true }, 200, req);
  } catch (err) {
    console.error('handleDeleteClient error:', err);
    return errorResponse('Server error', 500, req);
  }
}

// ─── API: /api/invoices ───────────────────────────────────────────────────────

async function handleGetInvoices(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  try {
    const db = supabase(env);
    const invoices = await db.select('invoices', `?user_id=eq.${user.sub}&order=created_at.desc`);
    return jsonResponse(invoices, 200, req);
  } catch (err) {
    console.error('handleGetInvoices error:', err);
    return errorResponse('Server error', 500, req);
  }
}

async function handleGetInvoicePublic(req, env, invoiceId) {
  try {
    const db = supabase(env);
    const invoices = await db.select('invoices', `?id=eq.${invoiceId}`);
    if (!invoices.length) return errorResponse('Invoice not found', 404, req);
    const invoice = invoices[0];
    const entries = await db.select('time_entries', `?invoice_id=eq.${invoiceId}&order=entry_date.asc`);
    let client = null;
    if (invoice.client_id) {
      const clients = await db.select('clients', `?id=eq.${invoice.client_id}`);
      client = clients[0] || null;
    }
    return jsonResponse({ invoice, entries, client }, 200, req);
  } catch (err) {
    console.error('handleGetInvoicePublic error:', err);
    return errorResponse('Server error', 500, req);
  }
}

async function handleCreateInvoice(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  let body;
  try { body = await req.json(); } catch { return errorResponse('Invalid JSON', 400, req); }

  const { entry_ids, client_id, notes } = body;
  if (!entry_ids || !entry_ids.length) return errorResponse('entry_ids required', 400, req);
  if (!client_id) return errorResponse('client_id required', 400, req);

  try {
    const db = supabase(env);
    const entryQuery = `?id=in.(${entry_ids.join(',')})&user_id=eq.${user.sub}`;
    const entries = await db.select('time_entries', entryQuery);
    if (entries.length !== entry_ids.length) return errorResponse('Some entries not found or not owned by you', 400, req);

    const clients = await db.select('clients', `?id=eq.${client_id}&user_id=eq.${user.sub}`);
    if (!clients.length) return errorResponse('Client not found', 404, req);
    const client = clients[0];

    function calcMins(start, end) {
      const [sh, sm] = start.split(':').map(Number);
      const [eh, em] = end.split(':').map(Number);
      return (eh * 60 + em) - (sh * 60 + sm);
    }

    let subtotal = 0;
    for (const e of entries) {
      const mins = calcMins(e.start_time, e.end_time);
      const hours = mins / 60;
      subtotal += hours * (parseFloat(e.rate) || 0);
    }

    const includeTax = body.include_tax !== false; // default true unless explicitly false
    const taxRate = includeTax ? 0.10 : 0;
    const taxAmount = subtotal * taxRate;
    const total = subtotal + taxAmount;

    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const rand = Math.floor(1000 + Math.random() * 9000);
    const invoiceNumber = `INV-${dateStr}-${rand}`;

    const totalCents = Math.round(total * 100);
    const stripeLink = await createStripePaymentLink(
      env,
      invoiceNumber,
      totalCents,
      client.name,
      `Consulting services — ${entries.length} session${entries.length !== 1 ? 's' : ''}`
    );

    const invoiceRows = await db.insert('invoices', {
      user_id: user.sub,
      client_id,
      invoice_number: invoiceNumber,
      subtotal: Math.round(subtotal * 100) / 100,
      tax_rate: taxRate,
      tax_amount: Math.round(taxAmount * 100) / 100,
      total: Math.round(total * 100) / 100,
      stripe_payment_link: stripeLink,
      status: 'sent',
      notes: notes?.trim() || null,
    });
    const invoice = Array.isArray(invoiceRows) ? invoiceRows[0] : invoiceRows;

    for (const entryId of entry_ids) {
      await db.patch('time_entries', `?id=eq.${entryId}&user_id=eq.${user.sub}`, {
        invoice_id: invoice.id,
        paid: true,
        updated_at: new Date().toISOString(),
      });
    }

    return jsonResponse({ invoice, client, entries }, 201, req);
  } catch (err) {
    console.error('handleCreateInvoice error:', err);
    return errorResponse('Server error: ' + err.message, 500, req);
  }
}

// ─── API: /api/time ──────────────────────────────────────────────────────────

async function handleGetTimeEntries(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  try {
    const db = supabase(env);
    const entries = await db.select('time_entries', `?user_id=eq.${user.sub}&order=entry_date.desc,start_time.desc`);
    return jsonResponse(entries, 200, req);
  } catch (err) {
    console.error('handleGetTimeEntries error:', err);
    return errorResponse('Server error', 500, req);
  }
}

async function handleCreateTimeEntry(req, env) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  let body;
  try { body = await req.json(); } catch { return errorResponse('Invalid JSON', 400, req); }
  const { client_name, rate, entry_date, start_time, end_time, notes } = body;
  if (!client_name || !entry_date || !start_time || !end_time) {
    return errorResponse('client_name, entry_date, start_time, end_time are required', 400, req);
  }
  try {
    const db = supabase(env);
    const rows = await db.insert('time_entries', {
      user_id: user.sub,
      client_name: client_name.trim(),
      client_id: body.client_id || null,
      rate: parseFloat(rate) || 0,
      entry_date,
      start_time,
      end_time,
      notes: notes?.trim() || null,
    });
    return jsonResponse(Array.isArray(rows) ? rows[0] : rows, 201, req);
  } catch (err) {
    console.error('handleCreateTimeEntry error:', err);
    return errorResponse('Server error', 500, req);
  }
}

async function handleUpdateTimeEntry(req, env, entryId) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  if (!entryId) return errorResponse('Entry ID required', 400, req);
  let body;
  try { body = await req.json(); } catch { return errorResponse('Invalid JSON', 400, req); }
  const allowed = ['client_name', 'rate', 'entry_date', 'start_time', 'end_time', 'notes'];
  const updates = {};
  for (const key of allowed) {
    if (body[key] !== undefined) updates[key] = body[key];
  }
  updates.updated_at = new Date().toISOString();
  try {
    const db = supabase(env);
    const existing = await db.select('time_entries', `?id=eq.${entryId}&user_id=eq.${user.sub}`);
    if (!existing.length) return errorResponse('Entry not found', 404, req);
    const rows = await db.patch('time_entries', `?id=eq.${entryId}&user_id=eq.${user.sub}`, updates);
    return jsonResponse(Array.isArray(rows) ? rows[0] : rows, 200, req);
  } catch (err) {
    console.error('handleUpdateTimeEntry error:', err);
    return errorResponse('Server error', 500, req);
  }
}

async function handleDeleteTimeEntry(req, env, entryId) {
  const { user, error } = await requireAuth(req, env);
  if (!user) return errorResponse(error, 401, req);
  if (!entryId) return errorResponse('Entry ID required', 400, req);
  try {
    const db = supabase(env);
    const existing = await db.select('time_entries', `?id=eq.${entryId}&user_id=eq.${user.sub}`);
    if (!existing.length) return errorResponse('Entry not found', 404, req);
    await db.delete('time_entries', `?id=eq.${entryId}&user_id=eq.${user.sub}`);
    return jsonResponse({ deleted: true }, 200, req);
  } catch (err) {
    console.error('handleDeleteTimeEntry error:', err);
    return errorResponse('Server error', 500, req);
  }
}

// ─── Main router ─────────────────────────────────────────────────────────────

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const path = url.pathname;
    const method = req.method;

    // CORS preflight
    if (method === 'OPTIONS') return preflight(req);

    // Stripe webhook — MUST be before JWT auth (Stripe doesn't send Bearer)
    if (path === '/stripe/webhook' && method === 'POST') return handleStripeWebhook(req, env);

    // Auth routes
    if (path === '/auth/google' && method === 'GET') return handleGoogleAuth(req, env);
    if (path === '/auth/callback' && method === 'GET') return handleGoogleCallback(req, env);

    // API routes
    if (path === '/api/me' && method === 'GET') return handleMe(req, env);
    if (path === '/api/notes' && method === 'GET') return handleGetNotes(req, env);
    if (path === '/api/notes' && method === 'POST') return handleCreateNote(req, env);
    if (path.startsWith('/api/notes/') && method === 'DELETE') {
      const noteId = path.replace('/api/notes/', '');
      return handleDeleteNote(req, env, noteId);
    }

    // Time tracking routes
    if (path === '/api/time' && method === 'GET') return handleGetTimeEntries(req, env);
    if (path === '/api/time' && method === 'POST') return handleCreateTimeEntry(req, env);
    if (path.startsWith('/api/time/') && method === 'PATCH') {
      const entryId = path.replace('/api/time/', '');
      return handleUpdateTimeEntry(req, env, entryId);
    }
    if (path.startsWith('/api/time/') && method === 'DELETE') {
      const entryId = path.replace('/api/time/', '');
      return handleDeleteTimeEntry(req, env, entryId);
    }

    // Clients
    if (path === '/api/clients' && method === 'GET') return handleGetClients(req, env);
    if (path === '/api/clients' && method === 'POST') return handleCreateClient(req, env);
    if (path.startsWith('/api/clients/') && method === 'PATCH') {
      return handleUpdateClient(req, env, path.replace('/api/clients/', ''));
    }
    if (path.startsWith('/api/clients/') && method === 'DELETE') {
      return handleDeleteClient(req, env, path.replace('/api/clients/', ''));
    }

    // Invoices
    if (path === '/api/invoices' && method === 'GET') return handleGetInvoices(req, env);
    if (path === '/api/invoices' && method === 'POST') return handleCreateInvoice(req, env);
    if (path.startsWith('/api/invoices/') && path.endsWith('/public') && method === 'GET') {
      const invoiceId = path.replace('/api/invoices/', '').replace('/public', '');
      return handleGetInvoicePublic(req, env, invoiceId);
    }

    // Stripe checkout — requires auth
    if (path === '/stripe/checkout' && method === 'POST') {
      const { user, error } = await requireAuth(req, env);
      if (!user) return errorResponse(error, 401, req);
      return handleCreateCheckout(req, env, user);
    }

    // Research Intelligence routes
    if (path === '/api/research/scan' && method === 'POST') return handleResearchScan(req, env);
    if (path === '/api/research/checkout' && method === 'POST') return handleResearchCheckout(req, env);
    if (path === '/api/research/session' && method === 'GET') return handleResearchSession(req, env);

    // Telegram webhook
    if (path === '/api/telegram' && method === 'POST') return handleTelegram(req, env);

    // Disconnect Telegram
    if (path === '/api/disconnect-telegram' && method === 'POST') {
      const { user, error } = await requireAuth(req, env);
      if (!user) return errorResponse(error, 401, req);
      try {
        const db = supabase(env);
        await db.update('users', `?id=eq.${user.sub}`, { telegram_chat_id: null, updated_at: new Date().toISOString() });
        return jsonResponse({ disconnected: true }, 200, req);
      } catch (err) {
        return errorResponse('Server error', 500, req);
      }
    }

    // Manual resurrection trigger (GET /api/resurrect?force=true)
    if (path === '/api/resurrect' && method === 'GET') {
      const force = url.searchParams.get('force') === 'true';
      const result = await runResurrection(env, force);
      return jsonResponse(result, 200, req);
    }

    // Profile routes
    if (path === '/api/profile' && method === 'GET') return handleGetProfile(req, env);
    if (path === '/api/profile' && method === 'POST') return handleSaveProfile(req, env);

    // Day cycle routes
    if (path === '/api/cycle' && method === 'GET') return handleGetCycle(req, env);
    if (path === '/api/cycle/clear' && method === 'POST') {
      const { user, error } = await requireAuth(req, env);
      if (!user) return errorResponse(error, 401, req);
      const today = new Date().toISOString().slice(0, 10);
      const db = supabase(env);
      await db.delete('day_cycles', `?user_id=eq.${user.sub}&date=eq.${today}`).catch(() => {});
      return jsonResponse({ cleared: true }, 200, req);
    }

    // Health check
    if (path === '/') return jsonResponse({ status: 'InkThorn is here. Grumpily.' }, 200, req);

    return jsonResponse({ error: 'Not found' }, 404, req);
  },

  // ─── Cron trigger — runs daily at 10am CDT (15:00 UTC) ───────────────────
  async scheduled(event, env, ctx) {
    ctx.waitUntil(runResurrection(env, false));
  },
};
