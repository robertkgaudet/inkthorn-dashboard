-- ═══════════════════════════════════════════════════════════════════════════
-- InkThorn — Subscriptions Table Migration
-- Run this in the Supabase Dashboard SQL Editor:
--   https://supabase.com/dashboard/project/sfletwhbfxtsvluvtsur/sql/new
-- ═══════════════════════════════════════════════════════════════════════════

-- 1. Create the subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id text NOT NULL UNIQUE,
  stripe_customer_id text,
  stripe_subscription_id text,
  status text NOT NULL DEFAULT 'free',  -- 'free' | 'active' | 'canceled' | 'past_due'
  plan text DEFAULT 'free',             -- 'free' | 'pro'
  current_period_start timestamptz,
  current_period_end timestamptz,
  canceled_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 2. Enable Row Level Security
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- 3. Service role policy (allows Worker to do everything)
CREATE POLICY IF NOT EXISTS "Service role full access" ON subscriptions
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- 4. Manually set Rob's pro status (rgaudet2023@gmail.com)
--    user_id = 4977dc08-8ca3-4271-be11-ac81cfe8190d
--    Run AFTER the table is created above

INSERT INTO subscriptions (
  user_id,
  stripe_customer_id,
  status,
  plan,
  current_period_start,
  current_period_end,
  updated_at
) VALUES (
  '4977dc08-8ca3-4271-be11-ac81cfe8190d',
  null,
  'active',
  'pro',
  now(),
  now() + interval '1 year',
  now()
)
ON CONFLICT (user_id) DO UPDATE SET
  status = 'active',
  plan = 'pro',
  current_period_end = now() + interval '1 year',
  updated_at = now();
