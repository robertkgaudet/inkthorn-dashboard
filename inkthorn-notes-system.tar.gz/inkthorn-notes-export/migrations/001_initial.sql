-- InkThorn Notes — Initial Schema
-- Run against Supabase with service role key

-- Users table
create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  google_id text unique not null,
  email text unique not null,
  name text,
  avatar_url text,
  tier text default 'free' check (tier in ('free', 'pro')),
  telegram_chat_id text unique,
  telegram_link_code text unique,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Notes table
create table if not exists public.notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.users(id) on delete cascade not null,
  text text not null,
  category text default 'other' check (category in ('ideas', 'tasks', 'other')),
  source text default 'web' check (source in ('web', 'telegram')),
  created_at timestamptz default now()
);

-- Enable RLS
alter table public.users enable row level security;
alter table public.notes enable row level security;

-- RLS policies (for Supabase Auth — note: our worker uses service role key, bypasses RLS)
do $$ begin
  if not exists (
    select 1 from pg_policies where tablename = 'users' and policyname = 'Users can read own profile'
  ) then
    create policy "Users can read own profile" on public.users
      for select using (id = auth.uid()::uuid);
  end if;
end $$;

do $$ begin
  if not exists (
    select 1 from pg_policies where tablename = 'users' and policyname = 'Users can update own profile'
  ) then
    create policy "Users can update own profile" on public.users
      for update using (id = auth.uid()::uuid);
  end if;
end $$;

do $$ begin
  if not exists (
    select 1 from pg_policies where tablename = 'notes' and policyname = 'Users can read own notes'
  ) then
    create policy "Users can read own notes" on public.notes
      for select using (user_id = auth.uid()::uuid);
  end if;
end $$;

do $$ begin
  if not exists (
    select 1 from pg_policies where tablename = 'notes' and policyname = 'Users can insert own notes'
  ) then
    create policy "Users can insert own notes" on public.notes
      for insert with check (user_id = auth.uid()::uuid);
  end if;
end $$;

do $$ begin
  if not exists (
    select 1 from pg_policies where tablename = 'notes' and policyname = 'Users can delete own notes'
  ) then
    create policy "Users can delete own notes" on public.notes
      for delete using (user_id = auth.uid()::uuid);
  end if;
end $$;
