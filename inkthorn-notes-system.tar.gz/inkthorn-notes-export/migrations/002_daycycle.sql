-- InkThorn Day Cycle — new tables
-- Run this in Supabase SQL editor: https://sfletwhbfxtsvluvtsur.supabase.co

-- ─── profiles ────────────────────────────────────────────────────────────────
-- Stores the identity context used to generate personalized day cycles.

create table if not exists profiles (
  id           uuid default gen_random_uuid() primary key,
  user_id      uuid not null unique references users(id) on delete cascade,

  -- Location
  city         text,
  neighborhood text,
  lat          numeric(9,6),
  lng          numeric(9,6),
  timezone     text default 'America/Chicago',

  -- Work identity
  projects     text[],          -- ["building Reyla", "TextOS", "Stability SBIR"]
  role         text,            -- "founder", "freelancer", "developer", etc.
  work_style   text,            -- "deep work mornings", "evening builder", etc.

  -- Rhythm
  wake_time    text,            -- "7:00 AM"
  sleep_time   text,            -- "11:00 PM"
  chronotype   text,            -- "morning", "night", "flexible"

  -- People
  partner_name text,
  has_kids     boolean default false,
  kids         jsonb,           -- [{"name":"...", "age":5, "pickup_days":["mon","wed"]}]

  -- Interests (up to 10, stored as array of slugs)
  interests    text[],          -- ["soccer","live-music","cooking","reading"]

  -- Vibe (3 words)
  vibe_words   text[],          -- ["focused","active","connected"]

  -- Onboarding state
  onboarding_complete boolean default false,

  created_at   timestamptz default now(),
  updated_at   timestamptz default now()
);

-- Row-level security: users can only read/write their own profile
alter table profiles enable row level security;
create policy "profiles: own row only" on profiles
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- ─── day_cycles ──────────────────────────────────────────────────────────────
-- Caches the AI-generated day cycle per user per day.
-- One call to Claude per user per calendar day maximum.

create table if not exists day_cycles (
  id          uuid default gen_random_uuid() primary key,
  user_id     uuid not null references users(id) on delete cascade,
  date        date not null,                    -- "2026-05-31"
  cycle_json  jsonb not null,                   -- full cycle object
  generated_at timestamptz default now(),

  unique (user_id, date)
);

alter table day_cycles enable row level security;
create policy "day_cycles: own row only" on day_cycles
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- Index for fast daily lookups
create index if not exists day_cycles_user_date on day_cycles (user_id, date desc);
